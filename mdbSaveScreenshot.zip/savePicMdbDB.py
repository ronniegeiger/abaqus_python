from abaqusConstants import *
from abaqusGui import *
from kernelAccess import mdb, session
import os

thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)


###########################################################################
# Class definition
###########################################################################

class SavePicMdbDB(AFXDataDialog):

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, form):

        # Construct the base class.
        #

        AFXDataDialog.__init__(self, form, 'MDB Save Pic',
            self.OK|self.CANCEL, DIALOG_ACTIONS_SEPARATOR)

        l = FXLabel(p=self, text='Save current MDB Viewport to PNG File', opts=JUSTIFY_LEFT)
        l.setFont(getAFXFont(FONT_BOLD))
        VFrame_1 = FXVerticalFrame(p=self, opts=0, x=0, y=0, w=0, h=0,pl=0, pr=0, pt=0, pb=0)
        FXCheckButton(p=VFrame_1, text='Change Color', tgt=form.changeColorKW, sel=0)


        okBtn = self.getActionButton(self.ID_CLICKED_OK)
        okBtn.setText('OK')

