from abaqus import *
from caeModules import *
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import *
from abaqusConstants import *
import numpy as np
from os.path import join, abspath, basename, dirname


class MdbInfoClass:

    def __init__(self):
        self.current_viewport = session.viewports[session.viewports.keys()[0]]
        self.current_viewport_str = session.viewports.keys()[0]
        self.mod_obj = mdb.models[mdb.models.keys()[-1]]
        self.mdb_name = self.mod_obj.name
        self.mdb_file_name = basename(mdb.pathName)
        self.directory = dirname(mdb.pathName)
        self.mdb_asm = self.mod_obj.rootAssembly
        self.part_0_name_str = self.mod_obj.parts.keys()[0]

    def get_viewport_obj(self):
        return self.current_viewport

    def get_part_0_str(self):
        return self.part_0_name_str

    def get_mod_obj(self):
        return self.mod_obj

    def get_mdb_name(self):
        return self.mdb_name

    def get_mdb_file_name(self):
        return self.mdb_file_name

    def get_directory(self):
        return self.directory

    def get_asm(self):
        return self.mdb_asm


def check_if_exists(file_path, ending):
    from os.path import exists
    i = 0
    while exists(file_path):
        if i == 1:
            file_path = file_path.replace(ending, '_' + str(i) + ending)
        else:
            file_path = file_path.replace('_' + str(i - 1) + ending, '_' + str(i) + ending)
        i = i + 1
    return file_path


def save_pic_mdb(change_color = True):
    print('\n{:-^70}'.format(''))
    print('{:~^70}'.format('MDB Save Viewport'))
    this_mdb = MdbInfoClass()
    current_viewport_obj = this_mdb.get_viewport_obj()

    current_viewport_obj.assemblyDisplay.geometryOptions.setValues(datumPoints=OFF, datumAxes=OFF, datumPlanes=OFF,
                                                                   datumCoordSystems=OFF, referencePointLabels=OFF,
                                                                   referencePointSymbols=OFF)
    if change_color:
        current_viewport_obj.enableMultipleColors()
        current_viewport_obj.setColor(initialColor='#BDBDBD')
        cmap = session.viewports['Viewport: 1'].colorMappings['Part']
        # cmap = current_viewport_obj.colorMappings['Part']
        parts = []
        for part in this_mdb.get_asm().instances.keys():
            parts.append(part)
        parts = sorted(parts)

        # Add here HEX Color Codes for individual colors (e.g. corporate design colors)
        colors = ['#009682', '#4664AA', '#D9D9D9', '#4CB5A7', '#7D92C3', '#7FCAC0', '#005A4E']
		
        if len(parts) < 8:
            for i in range(len(parts)):
                print('Color change of part {:25s} to {:7s}'.format(parts[i], colors[i]))
                cmap.updateOverrides(overrides={'{}'.format(parts[i]): (True, '{}'.format(colors[i]), 'Default',
                                                                        '{}'.format(colors[i]))})

        current_viewport_obj.setColor(colorMapping=cmap)
        current_viewport_obj.disableMultipleColors()

    current_viewport_obj.viewportAnnotationOptions.setValues(triad=OFF, legend=OFF, title=OFF, state=OFF,
                                                             annotations=OFF, compass=OFF)

    f_name = check_if_exists(
        join(this_mdb.get_directory(), this_mdb.get_mdb_name() + '_' + this_mdb.get_part_0_str().lower() + '_mdb.png'), '.png')
    print(f_name)
    session.pngOptions.setValues(imageSize=(4096, 2101))
    session.printToFile(fileName=f_name, format=PNG, canvasObjects=(current_viewport_obj,))
    print('{:~^70}'.format('End'))
    print('{:-^70}\n'.format(''))
    return True

if __name__ == "__main__":
    save_pic_mdb(False)
