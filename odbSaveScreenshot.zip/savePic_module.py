from abaqus import *
from caeModules import *
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
from abaqusConstants import *
import numpy as np
from os.path import join, abspath, basename, dirname


class OdbInfoClass:

    def __init__(self):
        self.current_viewport = session.viewports[session.viewports.keys()[0]]
        self.current_viewport_str = session.viewports.keys()[0]
        self.odb_obj = self.current_viewport.displayedObject
        self.odb_name = basename(self.odb_obj.name).replace('.odb','')
        self.odb_file_name = basename(self.odb_obj.name)
        self.directory = dirname(self.odb_obj.name)

    def get_odb_obj_from_viewport(self):
        return self.odb_obj

    def get_odb_name(self):
        return self.odb_name

    def get_odb_name(self):
        return self.odb_name

    def get_viewport_obj(self):
        return self.current_viewport

    def get_viewport_name_str(self):
        return self.current_viewport_str

    def get_directory(self):
        return self.directory


def check_if_exists(file_path, ending):
    from os.path import exists
    i = 0
    while exists(file_path):
        if i == 1:
            file_path = file_path.replace(ending, '_' + str(i) + ending)
        else:
            file_path = file_path.replace('_' + str(i - 1) + ending, '_' + str(i) + ending)
        i = i + 1
    return file_path


def save_pic(is_net_display, legend_size, legend_color, font_type = 'arial'):
    print('\n{:-^70}'.format(''))
    print('{:~^70}'.format('ODB Save Viewport'))
    this_odb = OdbInfoClass()
    odb_name = this_odb.get_odb_name()
    current_viewport_obj = this_odb.get_viewport_obj()

    # Legend Size
    if 'palatino'  in font_type:
        session.viewports['Viewport: 1'].viewportAnnotationOptions.setValues(
            legendFont='-*-palatino linotype-medium-r-normal-*-*-{:2s}0-*-*-p-*-*-*'.format(legend_size))
    else:
        current_viewport_obj.viewportAnnotationOptions.setValues(
            legendFont='-*-arial-medium-r-normal-*-*-{:2s}0-*-*-p-*-*-*'.format(legend_size))
    # current_viewport_obj.viewportAnnotationOptions.setValues(legendFont='-*-verdana-medium-r-normal-*-*-{:2s}0-*-*-p-*-*-*'.format('10'))
    # Legend Colour
    if 'black' in legend_color.lower():
        current_viewport_obj.viewportAnnotationOptions.setValues(legendTextColor='#000000')
    else:
        current_viewport_obj.viewportAnnotationOptions.setValues(legendTextColor='#FFFFFF')

    # Show net
    if is_net_display:
        current_viewport_obj.odbDisplay.commonOptions.setValues(visibleEdges=ALL)
    else:
        current_viewport_obj.odbDisplay.commonOptions.setValues(visibleEdges=FREE)

    f_name = check_if_exists(join(this_odb.get_directory(), this_odb.get_odb_name()+'_odb.png'), '.png')
    print(f_name)
    session.pngOptions.setValues(imageSize=(4096, 2101))
    session.printToFile(fileName=f_name, format=PNG, canvasObjects=(current_viewport_obj,))
    print('{:~^70}'.format('End'))
    print('{:-^70}\n'.format(''))
    return True


if __name__ == "__main__":
    save_pic(True, '14', 'white', 'arial')
