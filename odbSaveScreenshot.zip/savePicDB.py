from abaqusConstants import *
from abaqusGui import *
from kernelAccess import mdb, session
import os

thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)


###########################################################################
# Class definition
###########################################################################

class SavePicDB(AFXDataDialog):

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, form):

        # Construct the base class.
        #

        AFXDataDialog.__init__(self, form, 'Save Screenshot',
            self.OK|self.CANCEL, DIALOG_ACTIONS_SEPARATOR)
            

        okBtn = self.getActionButton(self.ID_CLICKED_OK)
        okBtn.setText('OK')
            
        FXCheckButton(p=self, text='Show net', tgt=form.is_net_displayKw, sel=0)
        ComboBox_0 = AFXComboBox(p=self, ncols=0, nvis=1, text='Font Name', tgt=form.font_typeKW, sel=0)
        ComboBox_0.setMaxVisible(10)
        ComboBox_0.appendItem(text='Arial')
        ComboBox_0.appendItem(text='Palatino')
        ComboBox_1 = AFXComboBox(p=self, ncols=0, nvis=1, text='Legend Size', tgt=form.legend_sizeKw, sel=0)
        ComboBox_1.setMaxVisible(10)
        ComboBox_1.appendItem(text='10')
        ComboBox_1.appendItem(text='14')
        ComboBox_1.appendItem(text='18')
        ComboBox_2 = AFXComboBox(p=self, ncols=0, nvis=1, text='Legend Color', tgt=form.legend_colorKw, sel=0)
        ComboBox_2.setMaxVisible(10)
        ComboBox_2.appendItem(text='white')
        ComboBox_2.appendItem(text='black')
